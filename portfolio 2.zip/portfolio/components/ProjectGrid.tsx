"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { categories, projects, type Category } from "@/data/projects";

export default function ProjectGrid() {
  const [active, setActive] = useState<Category | "all">("all");
  const list = active === "all" ? projects : projects.filter((p) => p.category === active);

  return (
    <div>
      <div role="tablist" aria-label="دسته‌بندی پروژه‌ها" className="mb-10 flex flex-wrap gap-2">
        {categories.map((c) => (
          <button
            key={c.id}
            role="tab"
            aria-selected={active === c.id}
            onClick={() => setActive(c.id)}
            className={`rounded-full border px-4 py-1.5 text-sm transition ${
              active === c.id ? "border-gold bg-gold text-ink" : "border-linen/25 hover:border-gold"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => (
          <li key={p.slug}>
            <Link href={`/projects/${p.slug}`} className="group block">
              <div className="relative aspect-[4/5] overflow-hidden bg-gradient-to-br from-royal via-emerald to-ink">
                {p.cover && (
                  <Image
                    src={p.cover}
                    alt={`${p.title} (${p.titleEn})`}
                    fill
                    sizes="(min-width:1024px) 33vw, 100vw"
                    style={{ objectPosition: p.coverPosition }}
                    className="object-cover transition duration-700 group-hover:scale-[1.04]"
                  />
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink via-ink/70 to-transparent p-5 pt-16">
                  <h3 className="text-xl font-bold text-gold">{p.title}</h3>
                  <p className="font-display text-sm italic text-linen/70">{p.titleEn}</p>
                </div>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
