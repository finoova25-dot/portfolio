export type Category = "iranpoosh" | "virtual-influencer" | "content" | "design";

export type Project = {
  slug: string;
  title: string;
  titleEn: string;
  category: Category;
  cover?: string;          // اگر نباشد، کارت با رنگ‌های برند ساخته می‌شود
  coverPosition?: string;  // برای برش تصویرهای بورد، مثل "10% 30%"
  summary: string;
  role: string;
  tools: string[];
  images: string[];
  video?: string;          // مسیر ویدیو در public/videos
  poster?: string;         // تصویر شاخص ویدیو
};

// پروژه جدید: فقط یک آبجکت به آرایه projects اضافه کن.
export const categories: { id: Category | "all"; label: string }[] = [
  { id: "all", label: "همه" },
  { id: "iranpoosh", label: "ایران‌پوش" },
  { id: "virtual-influencer", label: "اینفلوئنسر مجازی" },
  { id: "content", label: "تولید محتوا" },
  { id: "design", label: "طراحی" },
];

export const projects: Project[] = [
  {
    slug: "simurgh",
    title: "سیمرغیا",
    titleEn: "Simurghia",
    category: "iranpoosh",
    cover: "/images/simurgh.jpg",
    coverPosition: "20% 40%",
    summary: "شخصیت اصلی کالکشن: کت مخمل سرمه‌ای و زمردی، بال‌های زرین و شنل حریر. بورد کامل شامل نمای روبرو، سه‌رخ، نیم‌رخ، جزئیات پارچه و پالت رنگی.",
    role: "کارگردانی هنری، طراحی بورد و پرامپت",
    tools: ["Midjourney", "Photoshop"],
    images: ["/images/simurgh.jpg"],
  },
  {
    slug: "mitra-anahita-huma",
    title: "میترا، آناهیتا و هما",
    titleEn: "Mitra, Anahita, Huma",
    category: "iranpoosh",
    cover: "/images/mitra-anahita-huma.jpg",
    coverPosition: "50% 30%",
    summary: "سه ایزد و نماد در سه پالت: خورشید بی‌غروب (زرشکی و طلایی)، تندیس آب‌های زلال (آبی و نقره‌ای) و فرّ و سعادت (سرمه‌ای با پر).",
    role: "کارگردانی هنری، انتخاب پالت و پارچه",
    tools: ["Midjourney", "Photoshop"],
    images: ["/images/mitra-anahita-huma.jpg"],
  },
  {
    slug: "nahid",
    title: "ناهید",
    titleEn: "Nahid",
    category: "iranpoosh",
    cover: "/images/nahid.png",
    coverPosition: "15% 40%",
    summary: "الهه آب و ظرافت در حیاط آجری ایرانی؛ همراه با پرند و رکسانا، جزئیات پارچه و اکسسوری.",
    role: "کارگردانی هنری، لوکیشن و استایلینگ",
    tools: ["Midjourney", "Photoshop"],
    images: ["/images/nahid.png"],
  },
  {
    slug: "visual-identity-boards",
    title: "طراحی بوردهای هویت بصری",
    titleEn: "Visual Identity Boards",
    category: "design",
    cover: "/images/simurgh.jpg",
    coverPosition: "100% 50%",
    summary: "طراحی بوردهای بصری هفت شخصیت کالکشن اساطیر معاصر. هر بورد شامل سه نما (روبرو، سه‌رخ، نیم‌رخ)، جزئیات پارچه و اکسسوری، پالت رنگی چهارتایی و عنوان دوزبانه است. هدف این بود که هر شخصیت هویت مستقل داشته باشد و همه با یک زبان بصری واحد کنار هم بنشینند: مخمل، فلز و پر، در پالتی از آبی، زمردی، طلایی و زرشکی.",
    role: "طراحی چیدمان بورد، انتخاب پالت و پارچه، تایپوگرافی دوزبانه",
    tools: ["Midjourney", "Photoshop", "Figma"],
    images: ["/images/simurgh.jpg", "/images/mitra-anahita-huma.jpg", "/images/nahid.png"],
  },
  {
    slug: "iranpoosh-reel",
    title: "ویدیو و محتوای ایران‌پوش",
    titleEn: "Iranpoosh Reel",
    category: "content",
    cover: "/images/reel-poster.jpg",
    coverPosition: "50% 30%",
    summary: "ویدیوی کوتاه کالکشن اساطیر معاصر: شخصیت‌ها در حیاط و رواق‌های آجری ایرانی، از نمای کامل تا کلوزآپ جزئیات لباس. این قالب برای ریلز و پست‌های شبکه‌های اجتماعی برند تولید شد.",
    role: "ایده، کارگردانی هنری، تولید ویدیو و تدوین",
    tools: ["هوش مصنوعی مولد ویدیو", "CapCut"],
    images: [],
    video: "/videos/iranpoosh-reel.mp4",
    poster: "/images/reel-poster.jpg",
  },
  // ✏️ پروژه‌های بعدی را مثل نمونه‌های بالا اضافه کن
  {
    slug: "virtual-influencer",
    title: "اینفلوئنسر مجازی ایران‌پوش",
    titleEn: "Iranpoosh Virtual Influencer",
    category: "virtual-influencer",
    summary: "ساخت شخصیت مجازی برند، از طراحی چهره و استایل تا تولید محتوای ثابت برای شبکه‌های اجتماعی. (تصاویر و توضیح کامل را اضافه کن)",
    role: "طراحی شخصیت و تولید محتوا",
    tools: ["ComfyUI", "SDXL"],
    images: [],
  },
];
