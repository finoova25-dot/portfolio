import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { projects } from "@/data/projects";

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const p = projects.find((x) => x.slug === params.slug);
  return { title: p ? `${p.title} | پرتفولیو` : "پروژه" };
}

export default function ProjectPage({ params }: { params: { slug: string } }) {
  const p = projects.find((x) => x.slug === params.slug);
  if (!p) notFound();

  return (
    <main className="mx-auto max-w-6xl px-6 py-16">
      <Link href="/#projects" className="text-sm text-gold hover:underline">بازگشت به پروژه‌ها</Link>
      <h1 className="mt-6 text-4xl font-black">{p.title}</h1>
      <p className="font-display text-2xl italic text-linen/60">{p.titleEn}</p>

      <div className="mt-10 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          {p.video && <video src={p.video} poster={p.poster} controls playsInline preload="metadata" className="w-full bg-black" />}
          {p.images.length === 0 && !p.video && (
            <div className="grid aspect-video place-items-center bg-gradient-to-br from-royal via-emerald to-ink text-linen/70">
              تصاویر این پروژه به‌زودی اضافه می‌شود
            </div>
          )}
          {p.images.map((src) => (
            <Image key={src} src={src} alt={p.title} width={2000} height={1200} className="h-auto w-full" />
          ))}
          
        </div>
        <aside className="space-y-8 lg:sticky lg:top-8 lg:self-start">
          <p className="leading-9 text-linen/85">{p.summary}</p>
          <div>
            <h2 className="mb-2 font-bold text-gold">نقش من</h2>
            <p className="text-linen/80">{p.role}</p>
          </div>
          <div>
            <h2 className="mb-2 font-bold text-gold">ابزارها</h2>
            <p className="text-linen/80">{p.tools.join("، ")}</p>
          </div>
        </aside>
      </div>
    </main>
  );
}
