# پرتفولیو شخصی (Next.js 14)

## اجرا
npm install
npm run dev      # http://localhost:3000
npm run build    # ساخت نسخه نهایی

## ویرایش محتوا
- data/profile.ts: نام، درباره من، مهارت‌ها، سوابق، ایمیل و لینک‌ها
- data/projects.ts: پروژه‌ها (تصویر را در public/images بگذار و مسیرش را بنویس)
- tailwind.config.ts: رنگ‌های برند

## استقرار
مخزن را روی GitHub بگذار و در Vercel با Import Project منتشر کن.
