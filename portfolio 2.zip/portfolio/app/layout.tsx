import type { Metadata } from "next";
import { Vazirmatn, Cormorant_Garamond } from "next/font/google";
import "./globals.css";

const vazir = Vazirmatn({ subsets: ["arabic", "latin"], variable: "--font-vazir" });
const display = Cormorant_Garamond({ subsets: ["latin"], weight: ["400", "600", "700"], style: ["normal", "italic"], variable: "--font-display" });

export const metadata: Metadata = {
  title: "سارا | پرتفولیو",
  description: "برند، محتوا و تصویرسازی با هوش مصنوعی؛ نمونه‌کارهای ایران‌پوش | اساطیر معاصر",
  openGraph: { images: ["/images/simurgh.jpg"] },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={`${vazir.variable} ${display.variable}`}>
      <body>{children}</body>
    </html>
  );
}
