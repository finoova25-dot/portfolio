import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        royal: "#1E3A9E", emerald: "#0F6B4F", gold: "#C9A24B",
        ink: "#080C1A", crimson: "#8E1B2E", linen: "#EDE6D8",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-vazir)", "sans-serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
