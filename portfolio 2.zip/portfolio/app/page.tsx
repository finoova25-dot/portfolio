import Image from "next/image";
import ProjectGrid from "@/components/ProjectGrid";
import { profile } from "@/data/profile";

const nav = [
  { href: "#projects", label: "پروژه‌ها" },
  { href: "#about", label: "درباره من" },
  { href: "#skills", label: "مهارت‌ها" },
  { href: "#contact", label: "تماس" },
];

export default function Home() {
  return (
    <main>
      <header className="absolute inset-x-0 top-0 z-20 mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <a href="#" className="font-display text-2xl font-semibold text-gold">{profile.nameEn}</a>
        <nav aria-label="منو" className="flex gap-6 text-sm">
          {nav.map((n) => (
            <a key={n.href} href={n.href} className="hover:text-gold">{n.label}</a>
          ))}
        </nav>
      </header>

      {/* Hero: تصویر سیمرغیا مثل پرده‌ای باز می‌شود */}
      <section className="relative grid min-h-screen items-end lg:grid-cols-2">
        <div className="relative z-10 mx-auto w-full max-w-xl px-6 pb-20 pt-40 lg:pr-16">
          <h1 className="rise text-4xl font-black leading-[1.35] sm:text-5xl">{profile.headline}</h1>
          <p className="rise mt-6 text-lg text-linen/75" style={{ animationDelay: ".25s" }}>{profile.title}</p>
          <div className="rise mt-10 flex gap-4" style={{ animationDelay: ".4s" }}>
            <a href="#projects" className="bg-gold px-6 py-3 font-bold text-ink hover:bg-linen">مشاهده پروژه‌ها</a>
            <a href="#contact" className="border border-linen/30 px-6 py-3 hover:border-gold">تماس با من</a>
          </div>
        </div>
        <div className="unveil absolute inset-y-0 left-0 w-full lg:w-1/2">
          <Image src="/images/simurgh.jpg" alt="سیمرغیا، شخصیت کالکشن اساطیر معاصر" fill priority sizes="50vw" className="object-cover object-[18%_30%] opacity-50 lg:opacity-100" />
          <div className="absolute inset-0 bg-gradient-to-l from-ink via-transparent to-transparent" />
        </div>
      </section>

      <section id="projects" className="mx-auto max-w-7xl px-6 py-28">
        <h2 className="mb-12 text-3xl font-black">نمونه‌کارها</h2>
        <ProjectGrid />
      </section>

      <section id="about" className="border-y border-gold/15 bg-royal/10">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 py-28 lg:grid-cols-[1fr_2fr]">
          <h2 className="text-3xl font-black">درباره من</h2>
          <div className="max-w-2xl space-y-6 text-lg leading-9 text-linen/85">
            {profile.about.map((t) => <p key={t}>{t}</p>)}
            <ol className="mt-10 space-y-6 border-r border-gold/40 pr-6">
              {profile.experience.map((e) => (
                <li key={e.role}>
                  <p className="font-bold text-gold">{e.role}</p>
                  <p className="text-sm text-linen/60">{e.period}</p>
                  <p className="mt-1 text-base">{e.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section id="skills" className="mx-auto max-w-7xl px-6 py-28">
        <h2 className="mb-12 text-3xl font-black">مهارت‌ها</h2>
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {profile.skills.map((s) => (
            <div key={s.group}>
              <h3 className="mb-4 font-bold text-gold">{s.group}</h3>
              <ul className="space-y-2 text-linen/80">{s.items.map((i) => <li key={i}>{i}</li>)}</ul>
            </div>
          ))}
        </div>
      </section>

      <footer id="contact" className="border-t border-gold/15 px-6 py-24 text-center">
        <h2 className="mx-auto max-w-2xl text-3xl font-black leading-snug">اگر پروژه‌ای در ذهن دارید، با هم حرف بزنیم.</h2>
        <a href={`mailto:${profile.email}`} className="mt-8 inline-block bg-gold px-8 py-3 font-bold text-ink hover:bg-linen">ارسال ایمیل</a>
        <div className="mt-8 flex justify-center gap-8 text-sm text-linen/70">
          <a href={profile.linkedin} className="hover:text-gold" target="_blank" rel="noopener noreferrer">LinkedIn</a>
        </div>
      </footer>
    </main>
  );
}
